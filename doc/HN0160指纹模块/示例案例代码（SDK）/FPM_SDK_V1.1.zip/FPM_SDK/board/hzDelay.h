#ifndef _HZ_DELAY_H_
#define _HZ_DELAY_H_

#include "hzTypes.h"
#include "HC32L110.h"

void delayUs(UINT32 us);
void delayMs(UINT32 ms);
#endif
